from flask_bcrypt import Bcrypt

bcrypt = Bcrypt()

# Cifrar la contraseña
password = 'Password123'  # Cambia esto por la contraseña que deseas
hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

print(hashed_password)
