from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(50))
    cognoms = db.Column(db.String(50))
    edad = db.Column(db.Integer)
    email = db.Column(db.String(120))

class Activitat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(50))
    descripcio = db.Column(db.String(200))
    capacitat_maxima = db.Column(db.Integer)
