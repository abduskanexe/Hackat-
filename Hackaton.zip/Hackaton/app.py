from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
import json

app = Flask(__name__)

# Configuración de la base de datos
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://appuser:StrongPassword10@localhost/appActivitatsDB'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'StrongPassword10'

# Inicializar SQLAlchemy y Bcrypt
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

# Modelo de usuario
class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())

# Modelo de actividad
class Activity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)
    descripcio = db.Column(db.Text, nullable=True)
    capacitat_maxima = db.Column(db.Integer, nullable=False)

# Crear la tabla si no existe
with app.app_context():
    db.create_all()

@app.route('/')
def home():
    logged_in = session.get('user_logged_in', False)
    return render_template('index.html', logged_in=logged_in)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        user = User.query.filter_by(email=email).first()
        if user and bcrypt.check_password_hash(user.password, password):
            session['user_logged_in'] = True
            return redirect(url_for('home'))
        else:
            flash('Credenciales inválidas', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_logged_in', None)
    return redirect(url_for('home'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('El correo electrónico ya está registrado. Intenta con otro.', 'error')
            return redirect(url_for('register'))

        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        new_user = User(email=email, password=hashed_password)

        try:
            db.session.add(new_user)
            db.session.commit()
            flash('¡Registro exitoso! Por favor, inicia sesión.', 'success')
            return redirect(url_for('login'))
        except:
            db.session.rollback()
            flash('Hubo un problema al registrar el usuario. Inténtalo de nuevo.', 'error')
            return redirect(url_for('register'))

    return render_template('register.html')

# Ver todas las actividades
@app.route('/activities', methods=['GET', 'POST'])
def view_activities():
    if request.method == 'POST':
        # Si se envía el formulario de búsqueda
        search_query = request.form.get('query', '')
        activities = Activity.query.filter(Activity.nom.ilike(f'%{search_query}%')).all()
    else:
        # Si no se busca, mostrar todas las actividades
        activities = Activity.query.all()

    return render_template('activities.html', activities=activities)

# Crear una nueva actividad
@app.route('/create_activity', methods=['GET', 'POST'])
def create_activity():
    if request.method == 'POST':
        nom = request.form['nom']
        descripcio = request.form['descripcio']
        capacitat_maxima = request.form['capacitat_maxima']

        new_activity = Activity(nom=nom, descripcio=descripcio, capacitat_maxima=capacitat_maxima)
        db.session.add(new_activity)
        db.session.commit()

        return redirect(url_for('view_activities'))
    
    return render_template('create_activity.html')

# Importar actividades desde un archivo JSON
@app.route('/import_activities', methods=['POST'])
def import_activities():
    if 'file' not in request.files:
        flash('No se ha seleccionado ningún archivo', 'error')
        return redirect(url_for('view_activities'))

    file = request.files['file']
    if file.filename == '':
        flash('Nombre de archivo inválido', 'error')
        return redirect(url_for('view_activities'))

    # Leer el archivo JSON y cargar las actividades
    activities_data = json.load(file)
    for activity_data in activities_data:
        new_activity = Activity(
            nom=activity_data['nom'],
            descripcio=activity_data['descripció'],
            capacitat_maxima=activity_data['capacitat_màxima']
        )
        db.session.add(new_activity)
    db.session.commit()

    flash('Actividades importadas correctamente', 'success')
    return redirect(url_for('view_activities'))

# Exportar actividad como JSON
@app.route('/export_activity/<int:id>')
def export_activity(id):
    activity = Activity.query.get_or_404(id)
    activity_data = {
        'nom': activity.nom,
        'descripcio': activity.descripcio,
        'capacitat_màxima': activity.capacitat_maxima
    }

    return jsonify(activity_data)

if __name__ == '__main__':
    app.run(debug=True)
